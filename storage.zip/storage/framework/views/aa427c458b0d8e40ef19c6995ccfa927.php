<div>
    <h1 class="text-2xl font-bold text-gray-900">Dashboard</h1>
    <p class="mt-1 text-sm text-gray-500">Ringkasan stok dan transaksi mebel Anda.</p>

    
    <div class="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <div class="overflow-hidden rounded-lg bg-white px-4 py-5 shadow sm:p-6">
            <dt class="truncate text-sm font-medium text-gray-500">Total Produk</dt>
            <dd class="mt-1 text-3xl font-semibold tracking-tight text-gray-900"><?php echo e($totalProducts); ?></dd>
        </div>
        <div class="overflow-hidden rounded-lg bg-white px-4 py-5 shadow sm:p-6">
            <dt class="truncate text-sm font-medium text-gray-500">Total Merek</dt>
            <dd class="mt-1 text-3xl font-semibold tracking-tight text-gray-900"><?php echo e($totalBrands); ?></dd>
        </div>
        <div class="overflow-hidden rounded-lg bg-white px-4 py-5 shadow sm:p-6">
            <dt class="truncate text-sm font-medium text-gray-500">Total Kategori</dt>
            <dd class="mt-1 text-3xl font-semibold tracking-tight text-gray-900"><?php echo e($totalCategories); ?></dd>
        </div>
        <div class="overflow-hidden rounded-lg bg-white px-4 py-5 shadow sm:p-6">
            <dt class="truncate text-sm font-medium text-gray-500">Transaksi Hari Ini</dt>
            <dd class="mt-1 text-3xl font-semibold tracking-tight text-gray-900"><?php echo e($totalStockIn + $totalStockOut + $totalSales); ?></dd>
        </div>
    </div>

    
    <div class="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-3">
        <div class="overflow-hidden rounded-lg bg-green-50 border border-green-200 px-4 py-5 shadow sm:p-6">
            <dt class="truncate text-sm font-medium text-green-600">Barang Masuk</dt>
            <dd class="mt-1 text-3xl font-semibold tracking-tight text-green-700"><?php echo e($totalStockIn); ?></dd>
        </div>
        <div class="overflow-hidden rounded-lg bg-orange-50 border border-orange-200 px-4 py-5 shadow sm:p-6">
            <dt class="truncate text-sm font-medium text-orange-600">Barang Keluar</dt>
            <dd class="mt-1 text-3xl font-semibold tracking-tight text-orange-700"><?php echo e($totalStockOut); ?></dd>
        </div>
        <div class="overflow-hidden rounded-lg bg-blue-50 border border-blue-200 px-4 py-5 shadow sm:p-6">
            <dt class="truncate text-sm font-medium text-blue-600">Penjualan</dt>
            <dd class="mt-1 text-3xl font-semibold tracking-tight text-blue-700"><?php echo e($totalSales); ?></dd>
        </div>
    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lowStockProducts->count() > 0): ?>
    <div class="mt-8">
        <h2 class="text-lg font-semibold text-red-600">⚠️ Stok Menipis (≤ 5 unit)</h2>
        <div class="mt-3 overflow-hidden shadow ring-1 ring-black/5 sm:rounded-lg">
            <table class="min-w-full divide-y divide-gray-300">
                <thead class="bg-red-50">
                    <tr>
                        <th class="py-3 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">SKU</th>
                        <th class="px-3 py-3 text-left text-sm font-semibold text-gray-900">Nama Produk</th>
                        <th class="px-3 py-3 text-right text-sm font-semibold text-gray-900">Stok</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200 bg-white">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $lowStockProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <tr>
                        <td class="whitespace-nowrap py-3 pl-4 pr-3 text-sm font-medium text-gray-900"><?php echo e($product->sku); ?></td>
                        <td class="whitespace-nowrap px-3 py-3 text-sm text-gray-500"><?php echo e($product->name); ?></td>
                        <td class="whitespace-nowrap px-3 py-3 text-sm text-right">
                            <span class="inline-flex items-center rounded-md bg-red-100 px-2 py-1 text-xs font-medium text-red-700"><?php echo e($product->current_stock); ?></span>
                        </td>
                    </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="mt-8">
        <h2 class="text-lg font-semibold text-gray-900">Transaksi Terbaru</h2>
        <div class="mt-3 overflow-hidden shadow ring-1 ring-black/5 sm:rounded-lg">
            <table class="min-w-full divide-y divide-gray-300">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="py-3 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">Kode Referensi</th>
                        <th class="px-3 py-3 text-left text-sm font-semibold text-gray-900">Tipe</th>
                        <th class="px-3 py-3 text-left text-sm font-semibold text-gray-900">Tanggal</th>
                        <th class="px-3 py-3 text-left text-sm font-semibold text-gray-900">User</th>
                        <th class="px-3 py-3 text-right text-sm font-semibold text-gray-900">Total</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200 bg-white">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $recentTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <tr>
                        <td class="whitespace-nowrap py-3 pl-4 pr-3 text-sm font-medium text-gray-900"><?php echo e($trx->reference_code); ?></td>
                        <td class="whitespace-nowrap px-3 py-3 text-sm">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($trx->type === 'in'): ?>
                                <span class="inline-flex items-center rounded-md bg-green-100 px-2 py-1 text-xs font-medium text-green-700">Masuk</span>
                            <?php elseif($trx->type === 'out'): ?>
                                <span class="inline-flex items-center rounded-md bg-orange-100 px-2 py-1 text-xs font-medium text-orange-700">Keluar</span>
                            <?php else: ?>
                                <span class="inline-flex items-center rounded-md bg-blue-100 px-2 py-1 text-xs font-medium text-blue-700">Penjualan</span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </td>
                        <td class="whitespace-nowrap px-3 py-3 text-sm text-gray-500"><?php echo e($trx->transaction_date->format('d M Y')); ?></td>
                        <td class="whitespace-nowrap px-3 py-3 text-sm text-gray-500"><?php echo e($trx->user->name ?? '-'); ?></td>
                        <td class="whitespace-nowrap px-3 py-3 text-sm text-right text-gray-500">Rp <?php echo e(number_format($trx->total_amount ?? 0, 0, ',', '.')); ?></td>
                    </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    <tr>
                        <td colspan="5" class="py-4 text-center text-sm text-gray-500">Belum ada transaksi.</td>
                    </tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php /**PATH D:\APP\mebel\resources\views/livewire/dashboard.blade.php ENDPATH**/ ?>