<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title><?php echo e($reportTitle ?? 'Laporan'); ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Helvetica', 'Arial', sans-serif; font-size: 11px; padding: 30px; color: #333; }
        .header { text-align: center; border-bottom: 2px solid #4f46e5; padding-bottom: 10px; margin-bottom: 20px; }
        .header h1 { font-size: 18px; margin-bottom: 5px; color: #1e1b4b; }
        .header h2 { font-size: 14px; color: #4f46e5; margin-bottom: 5px; }
        .header p { font-size: 10px; color: #666; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { background: #4f46e5; color: #fff; font-size: 10px; padding: 8px; text-align: left; }
        td { padding: 6px 8px; border-bottom: 1px solid #ddd; font-size: 10px; vertical-align: top; }
        tr:nth-child(even) td { background: #f9f9f9; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .font-bold { font-weight: bold; }
        .badge { padding: 2px 6px; border-radius: 4px; font-size: 9px; font-weight: bold; color: #fff; }
        .bg-green { background: #10b981; }
        .bg-orange { background: #f97316; }
        .bg-blue { background: #3b82f6; }
        .bg-red { background: #ef4444; }
        .bg-gray { background: #6b7280; }
        .footer { margin-top: 30px; font-size: 9px; text-align: center; color: #999; border-top: 1px solid #ddd; padding-top: 10px; }
    </style>
</head>
<body>
    <div class="header">
        <h1><?php echo e(config('app.name', 'Mebel Stock')); ?></h1>
        <h2><?php echo e($reportTitle ?? 'Laporan'); ?></h2>
        <p>
            Periode: <?php echo e($dateFrom ? \Carbon\Carbon::parse($dateFrom)->format('d/m/Y') : 'Awal'); ?> - <?php echo e($dateTo ? \Carbon\Carbon::parse($dateTo)->format('d/m/Y') : 'Akhir'); ?>

            <br>Dicetak: <?php echo e(date('d/m/Y H:i:s')); ?>

        </p>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tab === 'transactions'): ?>
        <table>
            <thead>
                <tr>
                    <th>Kode</th>
                    <th>Tipe</th>
                    <th>Tanggal</th>
                    <th>User</th>
                    <th>Item Produk</th>
                    <th>Qty</th>
                    <th class="text-right">Harga</th>
                    <th class="text-right">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $grandTotal = 0; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $trx->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php $subtotal = $detail->quantity * $detail->price_at_transaction; $grandTotal += $subtotal; ?>
                    <tr>
                        <td class="font-bold"><?php echo e($idx === 0 ? $trx->reference_code : ''); ?></td>
                        <td>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($idx === 0): ?>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($trx->type === 'in'): ?> <span class="badge bg-green">Masuk</span>
                                <?php elseif($trx->type === 'out'): ?> <span class="badge bg-orange">Keluar</span>
                                <?php else: ?> <span class="badge bg-blue">Penjualan</span> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </td>
                        <td><?php echo e($idx === 0 ? $trx->transaction_date->format('d/m/Y') : ''); ?></td>
                        <td><?php echo e($idx === 0 ? ($trx->user->name ?? '-') : ''); ?></td>
                        <td><?php echo e($detail->product->name ?? '-'); ?></td>
                        <td class="text-center"><?php echo e($detail->quantity); ?></td>
                        <td class="text-right">Rp <?php echo e(number_format($detail->price_at_transaction, 0, ',', '.')); ?></td>
                        <td class="text-right font-bold">Rp <?php echo e(number_format($subtotal, 0, ',', '.')); ?></td>
                    </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <tr>
                    <td colspan="7" class="text-right font-bold">GRAND TOTAL</td>
                    <td class="text-right font-bold">Rp <?php echo e(number_format($grandTotal, 0, ',', '.')); ?></td>
                </tr>
            </tbody>
        </table>
    <?php elseif($tab === 'stock'): ?>
        <table>
            <thead>
                <tr>
                    <th>SKU</th>
                    <th>Kategori</th>
                    <th>Merek</th>
                    <th>Nama Produk</th>
                    <th class="text-right">Stok Fisik</th>
                    <th class="text-right">Harga Modal</th>
                    <th class="text-right">Nilai Aset</th>
                </tr>
            </thead>
            <tbody>
                <?php $totalAsset = 0; $totalQty = 0; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <?php 
                    $asset = $product->current_stock * $product->base_price; 
                    $totalAsset += $asset;
                    $totalQty += $product->current_stock;
                ?>
                <tr>
                    <td><?php echo e($product->sku); ?></td>
                    <td><?php echo e($product->category->name ?? '-'); ?></td>
                    <td><?php echo e($product->brand->name ?? '-'); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td class="text-right font-bold"><?php echo e($product->current_stock); ?></td>
                    <td class="text-right">Rp <?php echo e(number_format($product->base_price, 0, ',', '.')); ?></td>
                    <td class="text-right font-bold">Rp <?php echo e(number_format($asset, 0, ',', '.')); ?></td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <tr>
                    <td colspan="4" class="text-right font-bold">TOTAL KESELURUHAN</td>
                    <td class="text-right font-bold"><?php echo e($totalQty); ?> Unit</td>
                    <td></td>
                    <td class="text-right font-bold">Rp <?php echo e(number_format($totalAsset, 0, ',', '.')); ?></td>
                </tr>
            </tbody>
        </table>
    <?php elseif($tab === 'movement'): ?>
        <table>
            <thead>
                <tr>
                    <th>SKU</th>
                    <th>Nama Produk</th>
                    <th class="text-right">Masuk (In)</th>
                    <th class="text-right">Keluar (Out)</th>
                    <th class="text-right">Terjual (Sale)</th>
                    <th class="text-center">Status Mvmt</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $productsMove; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr>
                    <td><?php echo e($pm->sku); ?></td>
                    <td><?php echo e($pm->name); ?></td>
                    <td class="text-right"><?php echo e($pm->total_in); ?></td>
                    <td class="text-right"><?php echo e($pm->total_out); ?></td>
                    <td class="text-right font-bold"><?php echo e($pm->total_sale); ?></td>
                    <td class="text-center">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pm->total_sale > 10): ?> <span class="badge bg-green">Fast Moving</span>
                        <?php elseif($pm->total_sale > 0): ?> <span class="badge bg-blue">Normal</span>
                        <?php elseif($pm->total_in == 0 && $pm->total_sale == 0): ?> <span class="badge bg-red">Dead Stock</span>
                        <?php else: ?> <span class="badge bg-gray">Slow Moving</span> <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </tbody>
        </table>
    <?php elseif($tab === 'profit'): ?>
        <table>
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Referensi</th>
                    <th>Nama Produk</th>
                    <th class="text-right">Qty</th>
                    <th class="text-right">Harga Jual</th>
                    <th class="text-right">HPP</th>
                    <th class="text-right">Laba Kotor</th>
                </tr>
            </thead>
            <tbody>
                <?php $totalProfit = 0; $uniqueTransactions = []; $totalDiscount = 0; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $profitDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <?php
                    $hpp = $detail->product->base_price ?? 0;
                    $profit_per_unit = $detail->price_at_transaction - $hpp;
                    $total_profit = $profit_per_unit * $detail->quantity;
                    $totalProfit += $total_profit;
                    
                    if (!isset($uniqueTransactions[$detail->transaction_id])) {
                        $uniqueTransactions[$detail->transaction_id] = true;
                        $totalDiscount += $detail->transaction->discount;
                    }
                ?>
                <tr>
                    <td><?php echo e($detail->transaction->transaction_date->format('d/m/Y')); ?></td>
                    <td><?php echo e($detail->transaction->reference_code); ?></td>
                    <td><?php echo e($detail->product->name ?? '-'); ?></td>
                    <td class="text-right"><?php echo e($detail->quantity); ?></td>
                    <td class="text-right">Rp <?php echo e(number_format($detail->price_at_transaction, 0, ',', '.')); ?></td>
                    <td class="text-right">Rp <?php echo e(number_format($hpp, 0, ',', '.')); ?></td>
                    <td class="text-right font-bold">Rp <?php echo e(number_format($total_profit, 0, ',', '.')); ?></td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <tr>
                    <td colspan="6" class="text-right font-bold">TOTAL KEUNTUNGAN (BELUM POTONGAN)</td>
                    <td class="text-right font-bold">Rp <?php echo e(number_format($totalProfit, 0, ',', '.')); ?></td>
                </tr>
                <tr>
                    <td colspan="6" class="text-right font-bold">TOTAL POTONGAN DISKON</td>
                    <td class="text-right font-bold">- Rp <?php echo e(number_format($totalDiscount, 0, ',', '.')); ?></td>
                </tr>
                <tr>
                    <td colspan="6" class="text-right font-bold">TOTAL LABA KOTOR (SUDAH TERMASUK POTONGAN)</td>
                    <td class="text-right font-bold">Rp <?php echo e(number_format($totalProfit - $totalDiscount, 0, ',', '.')); ?></td>
                </tr>
            </tbody>
        </table>
    <?php elseif($tab === 'buy_price'): ?>
        <table>
            <thead>
                <tr>
                    <th>Tanggal Masuk</th>
                    <th>No. Referensi</th>
                    <th class="text-center">Kuantitas</th>
                    <th class="text-right">Harga Beli / Unit</th>
                    <th class="text-right">Total Nilai Transaksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $priceHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr>
                    <td><?php echo e(\Carbon\Carbon::parse($hist->transaction->transaction_date)->format('d/m/Y')); ?></td>
                    <td><?php echo e($hist->transaction->reference_code); ?></td>
                    <td class="text-center font-bold"><?php echo e($hist->quantity); ?></td>
                    <td class="text-right font-bold" style="color: #ef4444;">Rp <?php echo e(number_format($hist->price_at_transaction, 0, ',', '.')); ?></td>
                    <td class="text-right font-bold">Rp <?php echo e(number_format($hist->price_at_transaction * $hist->quantity, 0, ',', '.')); ?></td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($priceHistory) === 0): ?>
                <tr>
                    <td colspan="5" class="text-center">Belum ada riwayat transaksi barang masuk untuk produk ini di rentang waktu terpilih.</td>
                </tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
    <?php elseif($tab === 'expenses'): ?>
        <table>
            <thead>
                <tr>
                    <th>Tanggal</th>
                    <th>Kategori / Judul</th>
                    <th>Catatan</th>
                    <th class="text-right">Nominal</th>
                </tr>
            </thead>
            <tbody>
                <?php $totalExp = 0; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <?php $totalExp += $item->amount; ?>
                <tr>
                    <td><?php echo e($item->expense_date->format('d/m/Y')); ?></td>
                    <td class="font-bold"><?php echo e($item->category); ?></td>
                    <td><?php echo e($item->notes ?: '-'); ?></td>
                    <td class="text-right font-bold">Rp <?php echo e(number_format($item->amount, 0, ',', '.')); ?></td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <tr>
                    <td colspan="3" class="text-right font-bold">TOTAL PENGELUARAN</td>
                    <td class="text-right font-bold" style="color: #ef4444;">Rp <?php echo e(number_format($totalExp, 0, ',', '.')); ?></td>
                </tr>
            </tbody>
        </table>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="footer">
        <?php echo e(config('app.name')); ?> &copy; <?php echo e(date('Y')); ?> — Laporan ini di-generate secara otomatis oleh Sistem Manajemen Stok Mebel.
    </div>
</body>
</html>
<?php /**PATH D:\APP\mebel\resources\views/reports/pdf.blade.php ENDPATH**/ ?>