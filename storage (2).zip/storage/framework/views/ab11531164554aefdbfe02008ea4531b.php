<table class="min-w-full divide-y divide-gray-200">
    <thead class="bg-gray-50">
        <tr>
            <th class="py-3 pl-4 pr-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wide">Produk</th>
            <th class="px-3 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wide">Masuk (In)</th>
            <th class="px-3 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wide">Keluar (Out)</th>
            <th class="px-3 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wide">Terjual (Sale)</th>
            <th class="px-3 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wide">Status Movement</th>
        </tr>
    </thead>
    <tbody class="divide-y divide-gray-100 bg-white">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $productsMove; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <tr>
                <td class="py-3 pl-4 pr-3 text-sm text-gray-900">
                    <div class="font-medium"><?php echo e($pm->name); ?></div>
                    <div class="text-xs text-gray-500">SKU: <?php echo e($pm->sku); ?></div>
                </td>
                <td class="whitespace-nowrap px-3 py-3 text-sm text-right text-gray-700"><?php echo e($pm->total_in); ?></td>
                <td class="whitespace-nowrap px-3 py-3 text-sm text-right text-gray-700"><?php echo e($pm->total_out); ?></td>
                <td class="whitespace-nowrap px-3 py-3 text-sm text-right font-bold text-emerald-600"><?php echo e($pm->total_sale); ?></td>
                <td class="whitespace-nowrap px-3 py-3 text-sm text-center">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pm->total_sale > 10): ?>
                        <span class="inline-flex items-center rounded-full bg-emerald-100 px-2.5 py-0.5 text-xs font-semibold text-emerald-700">Fast Moving 🔥</span>
                    <?php elseif($pm->total_sale > 0): ?>
                        <span class="inline-flex items-center rounded-full bg-blue-100 px-2.5 py-0.5 text-xs font-semibold text-blue-700">Normal</span>
                    <?php elseif($pm->total_in == 0 && $pm->total_sale == 0): ?>
                        <span class="inline-flex items-center rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-semibold text-red-700">Dead Stock ⚠️</span>
                    <?php else: ?>
                        <span class="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-semibold text-gray-700">Slow Moving</span>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </td>
            </tr>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <tr>
            <td colspan="5" class="py-8 text-center text-sm text-gray-400">Tidak ada pergerakan barang pada periode ini.</td>
        </tr>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </tbody>
</table>
<?php /**PATH D:\APP\mebel\resources\views/reports/tables/movement.blade.php ENDPATH**/ ?>