<table class="min-w-full divide-y divide-gray-200">
    <thead class="bg-gray-50">
        <tr>
            <th class="py-3 pl-4 pr-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wide">Tanggal</th>
            <th class="px-3 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wide">Produk & Transaksi</th>
            <th class="px-3 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wide">Qty Terjual</th>
            <th class="px-3 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wide">Harga Jual/Unit</th>
            <th class="px-3 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wide">HPP / Modal</th>
            <th class="px-3 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wide">Laba Kotor</th>
        </tr>
    </thead>
    <tbody class="divide-y divide-gray-100 bg-white">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $profitDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <?php
                $hpp = $detail->product->base_price ?? 0;
                $profit_per_unit = $detail->price_at_transaction - $hpp;
                $total_profit = $profit_per_unit * $detail->quantity;
            ?>
            <tr>
                <td class="whitespace-nowrap py-3 pl-4 pr-3 text-sm text-gray-500">
                    <?php echo e($detail->transaction->transaction_date->format('d/m/Y')); ?>

                </td>
                <td class="py-3 px-3 text-sm text-gray-900">
                    <div class="font-medium"><?php echo e($detail->product->name ?? '-'); ?></div>
                    <div class="text-xs text-gray-400">Ref: <?php echo e($detail->transaction->reference_code); ?></div>
                </td>
                <td class="whitespace-nowrap px-3 py-3 text-sm text-right text-gray-900 font-bold">
                    <?php echo e($detail->quantity); ?>

                </td>
                <td class="whitespace-nowrap px-3 py-3 text-sm text-right text-gray-600">
                    Rp <?php echo e(number_format($detail->price_at_transaction, 0, ',', '.')); ?>

                </td>
                <td class="whitespace-nowrap px-3 py-3 text-sm text-right text-gray-500">
                    Rp <?php echo e(number_format($hpp, 0, ',', '.')); ?>

                </td>
                <td class="whitespace-nowrap px-3 py-3 text-sm text-right font-bold text-emerald-600">
                    Rp <?php echo e(number_format($total_profit, 0, ',', '.')); ?>

                </td>
            </tr>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <tr>
            <td colspan="6" class="py-8 text-center text-sm text-gray-400">Tidak ada data penjualan pada periode ini.</td>
        </tr>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </tbody>
</table>
<?php /**PATH D:\APP\mebel\resources\views/reports/tables/profit.blade.php ENDPATH**/ ?>