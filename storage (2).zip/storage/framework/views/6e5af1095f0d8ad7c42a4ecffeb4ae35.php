<table class="min-w-full divide-y divide-gray-200">
    <thead class="bg-gray-50">
        <tr>
            <th class="py-3 pl-4 pr-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wide">SKU</th>
            <th class="px-3 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wide">Nama Produk</th>
            <th class="px-3 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wide">Kategori & Merek</th>
            <th class="px-3 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wide">Fisik (Unit)</th>
            <th class="px-3 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wide">Harga Modal</th>
            <th class="px-3 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wide">Nilai Aset</th>
        </tr>
    </thead>
    <tbody class="divide-y divide-gray-100 bg-white">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <tr>
                <td class="whitespace-nowrap py-3 pl-4 pr-3 text-sm font-medium text-gray-900"><?php echo e($product->sku); ?></td>
                <td class="px-3 py-3 text-sm text-gray-900"><?php echo e($product->name); ?></td>
                <td class="px-3 py-3 text-sm text-gray-500">
                    <div><?php echo e($product->category->name ?? '-'); ?></div>
                    <div class="text-xs text-gray-400"><?php echo e($product->brand->name ?? '-'); ?></div>
                </td>
                <td class="whitespace-nowrap px-3 py-3 text-sm text-right font-bold <?php echo e($product->current_stock <= 5 ? 'text-red-600' : 'text-gray-900'); ?>">
                    <?php echo e($product->current_stock); ?>

                </td>
                <td class="whitespace-nowrap px-3 py-3 text-sm text-right text-gray-500">
                    Rp <?php echo e(number_format($product->base_price, 0, ',', '.')); ?>

                </td>
                <td class="whitespace-nowrap px-3 py-3 text-sm text-right font-medium text-purple-700">
                    Rp <?php echo e(number_format($product->current_stock * $product->base_price, 0, ',', '.')); ?>

                </td>
            </tr>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <tr>
            <td colspan="6" class="py-8 text-center text-sm text-gray-400">Tidak ada data stok.</td>
        </tr>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </tbody>
</table>
<?php /**PATH D:\APP\mebel\resources\views/reports/tables/stock.blade.php ENDPATH**/ ?>