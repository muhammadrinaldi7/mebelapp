<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($tab === 'transactions'): ?>
        <table>
            <thead>
                <tr><th colspan="8" style="text-align: center; font-size: 16px; font-weight: bold;"><?php echo e($reportTitle ?? 'Laporan Log Transaksi'); ?></th></tr>
                <tr><th colspan="8" style="text-align: center;">Periode: <?php echo e($dateFrom ? \Carbon\Carbon::parse($dateFrom)->format('d/m/Y') : 'Awal'); ?> - <?php echo e($dateTo ? \Carbon\Carbon::parse($dateTo)->format('d/m/Y') : 'Akhir'); ?></th></tr>
                <tr><th colspan="8"></th></tr>
                <tr>
                    <th style="font-weight: bold; text-align: left;">Kode Referensi</th>
                    <th style="font-weight: bold; text-align: left;">Tipe</th>
                    <th style="font-weight: bold; text-align: left;">Tanggal</th>
                    <th style="font-weight: bold; text-align: left;">User</th>
                    <th style="font-weight: bold; text-align: left;">Item Produk</th>
                    <th style="font-weight: bold; text-align: center;">Qty</th>
                    <th style="font-weight: bold; text-align: right;">Harga Satuan</th>
                    <th style="font-weight: bold; text-align: right;">Total Nilai</th>
                </tr>
            </thead>
            <tbody>
                <?php $grandTotal = 0; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $trx->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php $subtotal = $detail->quantity * $detail->price_at_transaction; $grandTotal += $subtotal; ?>
                    <tr>
                        <td style="font-weight: bold;"><?php echo e($idx === 0 ? $trx->reference_code : ''); ?></td>
                        <td><?php echo e($idx === 0 ? ($trx->type === 'in' ? 'Masuk' : ($trx->type === 'out' ? 'Keluar' : 'Penjualan')) : ''); ?></td>
                        <td><?php echo e($idx === 0 ? $trx->transaction_date->format('d/m/Y') : ''); ?></td>
                        <td><?php echo e($idx === 0 ? ($trx->user->name ?? '-') : ''); ?></td>
                        <td><?php echo e($detail->product->name ?? '-'); ?></td>
                        <td style="text-align: center;"><?php echo e($detail->quantity); ?></td>
                        <td style="text-align: right;"><?php echo e($detail->price_at_transaction); ?></td>
                        <td style="text-align: right; font-weight: bold;"><?php echo e($subtotal); ?></td>
                    </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <tr>
                    <td colspan="7" style="text-align: right; font-weight: bold;">GRAND TOTAL</td>
                    <td style="text-align: right; font-weight: bold;"><?php echo e($grandTotal); ?></td>
                </tr>
            </tbody>
        </table>
    <?php elseif($tab === 'stock'): ?>
        <table>
            <thead>
                <tr><th colspan="7" style="text-align: center; font-size: 16px; font-weight: bold;"><?php echo e($reportTitle ?? 'Laporan Stok & Valuasi Aset'); ?></th></tr>
                <tr><th colspan="7" style="text-align: center;">Dicetak: <?php echo e(date('d/m/Y H:i:s')); ?></th></tr>
                <tr><th colspan="7"></th></tr>
                <tr>
                    <th style="font-weight: bold; text-align: left;">SKU</th>
                    <th style="font-weight: bold; text-align: left;">Kategori</th>
                    <th style="font-weight: bold; text-align: left;">Merek</th>
                    <th style="font-weight: bold; text-align: left;">Nama Produk</th>
                    <th style="font-weight: bold; text-align: right;">Stok Fisik</th>
                    <th style="font-weight: bold; text-align: right;">Harga Modal</th>
                    <th style="font-weight: bold; text-align: right;">Total Nilai Aset</th>
                </tr>
            </thead>
            <tbody>
                <?php $totalAsset = 0; $totalQty = 0; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <?php 
                    $asset = $product->current_stock * $product->base_price; 
                    $totalAsset += $asset;
                    $totalQty += $product->current_stock;
                ?>
                <tr>
                    <td><?php echo e($product->sku); ?></td>
                    <td><?php echo e($product->category->name ?? '-'); ?></td>
                    <td><?php echo e($product->brand->name ?? '-'); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td style="text-align: right; font-weight: bold;"><?php echo e($product->current_stock); ?></td>
                    <td style="text-align: right;"><?php echo e($product->base_price); ?></td>
                    <td style="text-align: right; font-weight: bold;"><?php echo e($asset); ?></td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <tr>
                    <td colspan="4" style="text-align: right; font-weight: bold;">TOTAL KESELURUHAN</td>
                    <td style="text-align: right; font-weight: bold;"><?php echo e($totalQty); ?></td>
                    <td></td>
                    <td style="text-align: right; font-weight: bold;"><?php echo e($totalAsset); ?></td>
                </tr>
            </tbody>
        </table>
    <?php elseif($tab === 'movement'): ?>
        <table>
            <thead>
                <tr><th colspan="6" style="text-align: center; font-size: 16px; font-weight: bold;"><?php echo e($reportTitle ?? 'Pergerakan Fast & Slow Moving'); ?></th></tr>
                <tr><th colspan="6" style="text-align: center;">Periode: <?php echo e($dateFrom ? \Carbon\Carbon::parse($dateFrom)->format('d/m/Y') : 'Awal'); ?> - <?php echo e($dateTo ? \Carbon\Carbon::parse($dateTo)->format('d/m/Y') : 'Akhir'); ?></th></tr>
                <tr><th colspan="6"></th></tr>
                <tr>
                    <th style="font-weight: bold; text-align: left;">SKU</th>
                    <th style="font-weight: bold; text-align: left;">Nama Produk</th>
                    <th style="font-weight: bold; text-align: right;">Masuk (In)</th>
                    <th style="font-weight: bold; text-align: right;">Keluar (Out)</th>
                    <th style="font-weight: bold; text-align: right;">Terjual (Sale)</th>
                    <th style="font-weight: bold; text-align: center;">Status Movement</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $productsMove; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr>
                    <td><?php echo e($pm->sku); ?></td>
                    <td><?php echo e($pm->name); ?></td>
                    <td style="text-align: right;"><?php echo e($pm->total_in); ?></td>
                    <td style="text-align: right;"><?php echo e($pm->total_out); ?></td>
                    <td style="text-align: right; font-weight: bold;"><?php echo e($pm->total_sale); ?></td>
                    <td style="text-center">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pm->total_sale > 10): ?> Fast Moving
                        <?php elseif($pm->total_sale > 0): ?> Normal
                        <?php elseif($pm->total_in == 0 && $pm->total_sale == 0): ?> Dead Stock
                        <?php else: ?> Slow Moving <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </tbody>
        </table>
    <?php elseif($tab === 'profit'): ?>
        <table>
            <thead>
                <tr><th colspan="7" style="text-align: center; font-size: 16px; font-weight: bold;"><?php echo e($reportTitle ?? 'Laporan Keuntungan Kotor'); ?></th></tr>
                <tr><th colspan="7" style="text-align: center;">Periode: <?php echo e($dateFrom ? \Carbon\Carbon::parse($dateFrom)->format('d/m/Y') : 'Awal'); ?> - <?php echo e($dateTo ? \Carbon\Carbon::parse($dateTo)->format('d/m/Y') : 'Akhir'); ?></th></tr>
                <tr><th colspan="7"></th></tr>
                <tr>
                    <th style="font-weight: bold; text-align: left;">Tanggal</th>
                    <th style="font-weight: bold; text-align: left;">Referensi Penjualan</th>
                    <th style="font-weight: bold; text-align: left;">Nama Produk</th>
                    <th style="font-weight: bold; text-align: right;">Qty Terjual</th>
                    <th style="font-weight: bold; text-align: right;">Harga Jual Satuan</th>
                    <th style="font-weight: bold; text-align: right;">HPP (Modal Satuan)</th>
                    <th style="font-weight: bold; text-align: right;">Laba Kotor (Profit)</th>
                </tr>
            </thead>
            <tbody>
                <?php $totalProfit = 0; $uniqueTransactions = []; $totalDiscount = 0; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $profitDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <?php
                    $hpp = $detail->product->base_price ?? 0;
                    $profit_per_unit = $detail->price_at_transaction - $hpp;
                    $total_profit = $profit_per_unit * $detail->quantity;
                    $totalProfit += $total_profit;
                    
                    if (!isset($uniqueTransactions[$detail->transaction_id])) {
                        $uniqueTransactions[$detail->transaction_id] = true;
                        $totalDiscount += $detail->transaction->discount;
                    }
                ?>
                <tr>
                    <td><?php echo e($detail->transaction->transaction_date->format('d/m/Y')); ?></td>
                    <td><?php echo e($detail->transaction->reference_code); ?></td>
                    <td><?php echo e($detail->product->name ?? '-'); ?></td>
                    <td style="text-align: right;"><?php echo e($detail->quantity); ?></td>
                    <td style="text-align: right;"><?php echo e($detail->price_at_transaction); ?></td>
                    <td style="text-align: right;"><?php echo e($hpp); ?></td>
                    <td style="text-align: right; font-weight: bold;"><?php echo e($total_profit); ?></td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <tr>
                    <td colspan="6" style="text-align: right; font-weight: bold;">TOTAL Keuntungan (Belum Potongan)</td>
                    <td style="text-align: right; font-weight: bold;"><?php echo e($totalProfit); ?></td>
                </tr>
                <tr>
                    <td colspan="6" style="text-align: right; font-weight: bold;">TOTAL Potongan Diskon</td>
                    <td style="text-align: right; font-weight: bold;"><?php echo e($totalDiscount); ?></td>
                </tr>
                <tr>
                    <td colspan="6" style="text-align: right; font-weight: bold;">TOTAL Laba Kotor (Sudah Termasuk Potongan)</td>
                    <td style="text-align: right; font-weight: bold;"><?php echo e($totalProfit - $totalDiscount); ?></td>
                </tr>
            </tbody>
        </table>
    <?php elseif($tab === 'buy_price'): ?>
        <table>
            <thead>
                <tr><th colspan="5" style="text-align: center; font-size: 16px; font-weight: bold;"><?php echo e($reportTitle ?? 'Analisa Harga Beli'); ?></th></tr>
                <tr><th colspan="5" style="text-align: center;">Periode: <?php echo e($dateFrom ? \Carbon\Carbon::parse($dateFrom)->format('d/m/Y') : 'Awal'); ?> - <?php echo e($dateTo ? \Carbon\Carbon::parse($dateTo)->format('d/m/Y') : 'Akhir'); ?></th></tr>
                <tr><th colspan="5"></th></tr>
                <tr>
                    <th style="font-weight: bold; text-align: left;">Tanggal Masuk</th>
                    <th style="font-weight: bold; text-align: left;">No. Referensi</th>
                    <th style="font-weight: bold; text-align: center;">Kuantitas</th>
                    <th style="font-weight: bold; text-align: right;">Harga Beli / Unit</th>
                    <th style="font-weight: bold; text-align: right;">Total Nilai Transaksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $priceHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <tr>
                    <td><?php echo e(\Carbon\Carbon::parse($hist->transaction->transaction_date)->format('d/m/Y')); ?></td>
                    <td><?php echo e($hist->transaction->reference_code); ?></td>
                    <td style="text-align: center; font-weight: bold;"><?php echo e($hist->quantity); ?></td>
                    <td style="text-align: right; border: 1px solid #000; color: #ef4444; font-weight: bold;"><?php echo e($hist->price_at_transaction); ?></td>
                    <td style="text-align: right; font-weight: bold;"><?php echo e($hist->price_at_transaction * $hist->quantity); ?></td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($priceHistory) === 0): ?>
                <tr>
                    <td colspan="5" style="text-align: center;">Belum ada riwayat transaksi barang masuk untuk produk ini di rentang waktu terpilih.</td>
                </tr>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </tbody>
        </table>
    <?php elseif($tab === 'expenses'): ?>
        <table>
            <thead>
                <tr><th colspan="4" style="text-align: center; font-size: 16px; font-weight: bold;"><?php echo e($reportTitle ?? 'Laporan Pengeluaran Operasional'); ?></th></tr>
                <tr><th colspan="4" style="text-align: center;">Periode: <?php echo e($dateFrom ? \Carbon\Carbon::parse($dateFrom)->format('d/m/Y') : 'Awal'); ?> - <?php echo e($dateTo ? \Carbon\Carbon::parse($dateTo)->format('d/m/Y') : 'Akhir'); ?></th></tr>
                <tr><th colspan="4"></th></tr>
                <tr>
                    <th style="font-weight: bold; text-align: left;">Tanggal</th>
                    <th style="font-weight: bold; text-align: left;">Kategori / Judul</th>
                    <th style="font-weight: bold; text-align: left;">Catatan</th>
                    <th style="font-weight: bold; text-align: right;">Nominal (Rp)</th>
                </tr>
            </thead>
            <tbody>
                <?php $totalExp = 0; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <?php $totalExp += $item->amount; ?>
                <tr>
                    <td><?php echo e($item->expense_date->format('d/m/Y')); ?></td>
                    <td style="font-weight: bold;"><?php echo e($item->category); ?></td>
                    <td><?php echo e($item->notes ?: '-'); ?></td>
                    <td style="text-align: right; font-weight: bold;"><?php echo e($item->amount); ?></td>
                </tr>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <tr>
                    <td colspan="3" style="text-align: right; font-weight: bold;">TOTAL PENGELUARAN</td>
                    <td style="text-align: right; font-weight: bold; color: #ef4444;"><?php echo e($totalExp); ?></td>
                </tr>
            </tbody>
        </table>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</body>
</html>
<?php /**PATH D:\APP\mebel\resources\views/reports/excel.blade.php ENDPATH**/ ?>